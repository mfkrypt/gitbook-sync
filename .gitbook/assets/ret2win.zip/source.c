#include <stdio.h>
#include <stdlib.h>
#include <string.h>

// Win function
void win() {
    char buf[64];  
    FILE *f = fopen("flag.txt", "r");   

    fgets(buf, sizeof(buf), f);     
    fclose(f);

    printf("Ret2win successfull here is your flag: %s\n", buf);   
}


// Vuln function
void vuln() {
    char buffer[20];

    printf("What is your name\n> ");
    scanf("%s", buffer);   
    printf("Hey there, nice to meet ya %s\n", buffer);
}

// Main
int main() {
    vuln();
    return 0;
}
