#include <stdio.h>
#include <stdlib.h>
#include <string.h>

void auth(){

	int pass = 0x12345;
	char buffer[32];

	printf("What is the password?\n");
	fflush(stdout);
	gets(buffer);


	if (pass == 0xdead10cc){
		printf("Output: That is correct!\n");
		printf("%x", pass);
	} else {
		printf("Output: Wrong!\n");
		printf("%x", pass);
	}
}



int main(int argc, char *argv[]){
	auth();
	return 0;
}