
#include <stdio.h>
#include <stdlib.h>
#include <string.h>


void flag(int check, int check2) {
    if(check == 0xFACEB00C && check2 == 0x8BADF00D) {
        puts("How are you here??");
    } else {
    	puts("So close, yet so far...");
    }
}

void vuln() {
    char buffer[40];

    printf("There's nothing to see here right?\n> ");
    gets(buffer);
}

int main() {
    vuln();
    return 0;
}