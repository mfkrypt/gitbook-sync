
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

void rdi_func() {
    asm("pop %rdi; ret");
}

void flag(int check) {
    if(check == 0xFACEB00C) {
        puts("How are you here??");
    } else {
    	puts("So close, yet so far...");
    }
}

void vuln() {
    char buffer[40];

    printf("There's nothing to see here right?\n> ");
    gets(buffer);
}



int main() {
    vuln();
    return 0;
}